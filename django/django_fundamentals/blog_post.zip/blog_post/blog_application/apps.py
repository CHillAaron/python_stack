from django.apps import AppConfig


class BlogApplicationConfig(AppConfig):
    name = 'blog_application'
