from django.urls import path     
from . import views


urlpatterns = [
    path('', views.index),
    path('home', views.home),	 
    path('register', views.register), 
    path('logIn', views.logIn),
    path('wall', views.wall),
    path('newPost', views.newPost),
    path('deletePost<int:id>', views.DeletePost),
    path('reply', views.reply),
    path('logout', views.logout)
]