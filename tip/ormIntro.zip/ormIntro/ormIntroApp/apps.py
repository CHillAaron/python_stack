from django.apps import AppConfig


class OrmintroappConfig(AppConfig):
    name = 'ormIntroApp'
