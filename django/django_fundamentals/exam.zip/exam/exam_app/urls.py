from django.urls import path     
from . import views


urlpatterns = [
    path('', views.index),
    path('register', views.register),
    path('logIn', views.logIn),	   
    path('quotes', views.quotes),
    path('newQuote', views.newQuote),
    path('post/<int:id>/delete', views.delete),
    path('logout', views.logout),
    path('myaccount/<int:id>', views.edit),
    path('myaccount/<int:id>/edit', views.editAccount),
    path('users/<int:id>', views.userQuotes)
]