from django.shortcuts import render, HttpResponse, redirect
from .models import *
from django.contrib import messages

def index(request):
    context = {
        'account': User.objects.all()
    }
    return render(request, "index.html", context)

def register(request):
    errors = User.objects.userValidator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    else:
        newAccount = User.objects.create(first=request.POST['first'], last=request.POST['last'], email=request.POST['email'] , password=request.POST['password'])
        request.session ['loggedInId'] = newAccount.id
    return redirect('/quotes',)

def logIn(request):
    errors = User.objects.logInValidator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    else:
        matchingEmail = User.objects.filter(email=request.POST['email'])
        request.session['loggedInId'] = matchingEmail[0].id

    return redirect('/quotes')

def quotes(request):
    if 'loggedInId' not in request.session:
        return redirect('/')
    context = {
        'loggedIn': User.objects.get(id=request.session ['loggedInId']),
        "users": User.objects.all(),
        "post": Quote.objects.all()
    }
    return render(request, 'quotes.html', context)

def newQuote(request):
    context = {
        "users": User.objects.all(),
        "post": Quote.objects.all()
    }
    print('***'*10)
    print(request.POST)
    print('***'*10)

    errors = User.objects.quoteValidator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/quotes')
    else:
        poster = User.objects.get(id=request.session['loggedInId'])
        Quote.objects.create(body=request.POST['body'], author=request.POST['author'], usersPost = poster)
    return redirect('/quotes', context)

def delete(request, id):
    deleteMe = Quote.objects.get(id=id)
    deleteMe.delete()
    return redirect('/quotes')

def edit(request, id):
    context = {
        'account': User.objects.all(),
        'thisUser': User.objects.get(id=id)
    }
    return render(request, 'edit.html', context)

def editAccount(request, id):
    context = {
        'account': User.objects.all(),
        'thisUser': User.objects.get(id=id)
    }
    userUpdate = User.objects.get(id=id)
    userUpdate.first = request.POST['first']
    userUpdate.last = request.POST['last']
    userUpdate.email = request.POST['email']
    errors = User.objects.updateValidator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect(f'/myaccount/{id}')
    userUpdate.save()
    return redirect('/quotes', context)

def userQuotes(request, id):
    context = {
        'loggedIn': User.objects.get(id=request.session ['loggedInId']),
        "users": User.objects.all(),
        "post": Quote.objects.all(),
        'blogger': User.objects.get(id=id)
    }

    return render(request, 'userquotes.html', context)

def logout(request):
    request.session.clear()
    return redirect('/')

