from django.db import models
from datetime import date
import re

today = date.today()

#Validations go here
class UserManager(models.Manager):

    def logInValidator(self, formInfo):
        errors = {}
        matchingEmail = User.objects.filter(email=formInfo['email'])
        print(matchingEmail)
        if len(formInfo['email']) < 1:
            errors['emailRequired'] = "Email is required to login"
        elif len(matchingEmail) == 0:
            errors['emailNotFound'] = "No email, not registered"
        else:
            #check password
            if matchingEmail[0].password != formInfo['password']:
                errors['incorrectpassword'] = 'Try again'
        
        return errors

    def userValidator(self, formInfo):
        errors = {}
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        matchingEmail = User.objects.filter(email = formInfo['email'])
        User.objects.filter(email = formInfo['email'])

        if len(formInfo['first']) < 2:
            errors['first'] = "Your first name is to short"
        if len(formInfo['last']) < 2:
            errors['lastError'] = "Your last name is to short"
        if len(formInfo['email']) < 1:
            errors['emailRequired'] = "What is your email"
        elif not EMAIL_REGEX.match(formInfo['email']):            
            errors['email'] = "Invalid email address!"
        elif len(matchingEmail) > 0:
            errors['matchingemail'] = "this email is taken"
        if  len(formInfo['password']) < 8:    
            errors['pwError'] = "password to Short"
        if formInfo['password'] != formInfo['confirm']:
            errors['matchError'] = "Passwords do not match"
        return errors

    def updateValidator(self, formInfo):
        errors = {}
        matchingEmail = User.objects.filter(email=formInfo['email'])
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        User.objects.filter(email = formInfo['email'])
        # if matchingEmail[0].email == formInfo['email']
        if len(matchingEmail) > 0:
            errors['matchingemail'] = "this email is taken"
        if len(formInfo['email']) < 1:
            errors['emailRequired'] = "Please enter an email to update"
        if len(formInfo['first']) < 2:
            errors['first'] = "Your first name is to short"
        if len(formInfo['last']) < 2:
            errors['lastError'] = "Your last name is to short"
        return errors

    def quoteValidator(self, formInfo):
        errors = {}
        if len(formInfo['author']) < 3:
            errors['authorError'] = "There needs to be an author"
        if len(formInfo['body']) < 10:
            errors['bodyError'] = "No good quote is that short"
        return errors

# Models go here


class User(models.Model):
    first = models.CharField(max_length = 255)
    last = models.CharField(max_length = 255)
    email = models.CharField(max_length = 255)
    password = models.CharField(max_length = 255)
    created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True, null=True, blank=True)
    objects = UserManager()

class Quote(models.Model):
    author = models.CharField(max_length = 255)
    body = models.TextField()
    likes = models.ManyToManyField(User, related_name="likedPost") 
    usersPost = models.ForeignKey(User, related_name="userspost", on_delete = models.CASCADE, null=True)